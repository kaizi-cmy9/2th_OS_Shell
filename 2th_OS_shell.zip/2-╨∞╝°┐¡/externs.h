#ifndef _EXTERNS_H_
#define _EXTERNS_H_

#include "def.h"

extern char cmdline[MAXLINE+1];	//命令行
extern char avline[MAXLINE+1];	//解析后的命令行
extern COMMAND cmd;	//命令

#endif /* _EXTERNS_H_ */
