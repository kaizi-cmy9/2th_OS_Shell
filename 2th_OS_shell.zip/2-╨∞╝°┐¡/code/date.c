#include "lib/command_comm.h"
#include "lib/gettime.h"
#include "lib/is_digit.h"
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <getopt.h>
#include <errno.h>


static void date_usage_exit(int status)
{
    if(status != 0)
    {
        fprintf(stderr, "Try '%s --help' for more infomation\n",
                program_name);
    }
    else
    {
        printf("Usage: %s  [OPTION]\n", program_name);
        printf("-h  --help(--h)                         show the help infomation\n");
        printf("--date=[YEAR|MON|DAY|HOUR|MIN|SEC(a 14bit number)]      set the system time,auto set time needs to be turned off\n");
    }
    exit(status);
}

/*
    ���ַ���ʱ��ת��Ϊtm����

    ����ֵ:
        == 0    �ɹ�
        != 0    ʧ��

   FIXME
        �ַ���ʱ���֧������20000325124055(2000��3��25��12��40��55��)
*/
static int time_char2tm(char * ptime,  struct tm *t)
{
#define     MY_YEAR     4
#define     MY_MON      2
#define     MY_DAY      2
#define     MY_HOUR     2
#define     MY_MIC      2
#define     MY_SEC      2

    const int   time_size = 14; /*   Ӧ�ô����ʱ���ַ�������   */
    char        tmp[8];
    size_t      off_size = 0;
    int         tmp_n;

    if(ptime == NULL || t == NULL)
        return -10;

    if(strlen(ptime) != time_size) //trlen(const char *str) �����ַ��� str �ĳ��ȣ�ֱ���ս����ַ������������ս����ַ���
    {
        fprintf(stderr,
                "must a 14 bit date, for example(20140202112233)\n");
        return -1;
    }

    memset(t, 0, sizeof(struct tm));//memset(void *str, int c, size_t n) �����ַ� c��һ���޷����ַ��������� str ��ָ����ַ�����ǰ n ���ַ���

    if(is_digit(ptime, strlen(ptime)) == 0)
        return -2;

    /*  ȡ��    */
    strncpy(tmp, ptime + off_size, MY_YEAR);  //��strncpy(char *dest, const char *src, int n)����src��ָ����ַ�������src��ַ��ʼ��ǰn���ֽڸ��Ƶ�dest��ָ�������У�������dest��
    tmp[MY_YEAR] = 0;
    tmp_n = atoi(tmp);
    if(tmp_n < 1900)
        return -3;
    t->tm_year = tmp_n - 1900;
    off_size += MY_YEAR;

    /*  ȡ��    */
    strncpy(tmp, ptime + off_size, MY_MON);
    tmp[MY_MON] = 0;
    tmp_n = atoi(tmp);
    if(tmp_n < 1 || tmp_n > 12)
        return -4;
    t->tm_mon = tmp_n - 1;
    off_size += MY_MON;

    /*  ȡ��    */
    strncpy(tmp, ptime + off_size, MY_DAY);
    tmp[MY_DAY] = 0;
    tmp_n = atoi(tmp);
    if(tmp_n < 1 || tmp_n > 31)
        return -5;
    t->tm_mday = tmp_n;
    off_size += MY_DAY;

    /*  ȡʱ    */
    strncpy(tmp, ptime + off_size, MY_HOUR);
    tmp[MY_HOUR] = 0;
    tmp_n = atoi(tmp);
    if(tmp_n < 0 || tmp_n > 23)
        return -6;
    t->tm_hour = tmp_n;
    off_size += MY_HOUR;

    /*  ȡ��    */
    strncpy(tmp, ptime + off_size, MY_MIC);
    tmp[MY_MIC] = 0;
    tmp_n = atoi(tmp);
    if(tmp_n < 0 || tmp_n > 59)
        return -7;
    t->tm_min = tmp_n;
    off_size += MY_MIC;

    /*  ȡ��    */
    strncpy(tmp, ptime + off_size, MY_SEC);
    tmp[MY_SEC] = 0;
    tmp_n = atoi(tmp);
    if(tmp_n < 0 || tmp_n > 60)
        return -8;
    t->tm_sec = tmp_n;
    off_size += MY_SEC;

#undef     MY_YEAR
#undef     MY_MON
#undef     MY_DAY
#undef     MY_HOUR
#undef     MY_MIC
#undef     MY_SEC

    return 0;
}

static int pr_sys_time()//���ϵͳʱ��
{
    struct timeval          time_spec;
    int                     err;
    if((err = get_sys_time(&time_spec)) != 0)
        return -1;
    printf("%s", ctime(&time_spec.tv_sec));
    return 0;
}

static int set_sys_time(char *new_date)//����ϵͳʱ��
{
    struct tm           t_tm;
    struct timeval      t_timeval;
    int                 err;

    if((err = time_char2tm(new_date, &t_tm)) != 0)
    {
        fprintf(stderr,
                "[%s] is not a correct time\n",
                new_date);
        return err;
    }

    t_timeval.tv_sec = mktime(&t_tm);
    t_timeval.tv_usec = 0;

    if((err = settimeofday(&t_timeval, 0)) != 0)
    {
        if(errno == EPERM)
        {
            fprintf(stderr,
                    "[%s] is seted by root user\n",
                    program_name);

            return 0;
        }
        return -11;
    }
    return 0;
}
int main(int argc, char *argv[])
{
    int                     c;
    int                     is_set = 0;     /*  �Ƿ�������ʱ���־    */
    char                    *new_date = NULL;

    static struct option const long_options[] =
    {
        {"help", 0, NULL, 'h'},
        {"date", 1, NULL, 'd'},
        {NULL, 0, NULL, 0}
    };
    exit_status = 0;
    program_name = argv[0];
    while((c = getopt_long(argc, argv,
                           "hH", long_options, NULL)) != -1)
    {
        switch(c)
        {
            case 'h':
            case 'H':
                date_usage_exit(EXIT_SUCESS);
                break;
            case 'd':
                if (optarg)
                {
                    new_date=optarg;
                    is_set = 1;
                }
                break;
            default:
                date_usage_exit(EXIT_FAILURE);
                break;
        }
    }

    if(optind != argc)
        date_usage_exit(1);

    if(is_set && new_date != NULL)
        exit_status = set_sys_time(new_date);
    else
        exit_status = pr_sys_time();

    if(exit_status != 0)
        fprintf(stderr,
                "[%s] error with errno[%d]\n",
                program_name, exit_status);

    exit(exit_status);
}

